package suadi20;


public class luas_lingkaran {
    
    public static void main(String[] args) {
        int phi = 22/7;
        int r = 14;
        double Luas = phi * r * r;
        
        System.out.println ("jari jari = " + (r));
        System.out.println ("Luas Lingkaran = " + (Luas));
    }
    
}
